# Changelog

## 0.0.3 - 2015-12-08

* Add functions for template parsing: parse_template, parse_templates
* Add --force option 

## 0.0.2 - 2015-11-23

* Created utilities library -> common.sh
* Move Verbosity to an example
* Remove Quiet option
* Rename files and directories

## 0.0.1 - 2015-11-12

* First Release
