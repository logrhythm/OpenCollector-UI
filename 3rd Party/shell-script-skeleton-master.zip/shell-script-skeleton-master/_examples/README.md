# Project Examples

List of Shell Script Examples:
- [Verbosity](verbosity)

TODO: Add more examples here
- [Daemon](http://www.phcomp.co.uk/Tutorials/Unix-And-Linux/cat.php?file=SkeletonDaemon.sh)
- Configuration File
