# ###########################################
#
# LogRhythm SmartResponse Plug-In Editor
#
# ###############
#
# (c) 2019, LogRhythm
#
# ###############
#
# Change Log:
#
# v0.1 - 2019-08-09 - Tony Mass� (tony.masse@logrhythm.com)
# - Skeleton
# - Load UI from external YAML
#
# v0.9 - 2019-08-09 - Tony Mass� (tony.masse@logrhythm.com)
# - Navigation mapping (Left menu with screen/tabs)
# - Login tab, including all the option, fully working
# - Connection over SSH and disconnection
# - Connection status (bottom right of window)
# - Save and read configuration (for the Host)
# - Status tab, fully working
#
# ################
#
# TO DO
# - Everything
# - Save credentials in a safe way
# - Create the Internet Connection status check
#
# ################


########################################################################################################################
##################################### Variables, Constants and Function declaration ####################################
########################################################################################################################

#  888     888                  d8b          888      888                              .d8888b.                             888                      888             
#  888     888                  Y8P          888      888                             d88P  Y88b                            888                      888             
#  888     888                               888      888                             888    888                            888                      888             
#  Y88b   d88P  8888b.  888d888 888  8888b.  88888b.  888  .d88b.  .d8888b            888         .d88b.  88888b.  .d8888b  888888  8888b.  88888b.  888888 .d8888b  
#   Y88b d88P      "88b 888P"   888     "88b 888 "88b 888 d8P  Y8b 88K                888        d88""88b 888 "88b 88K      888        "88b 888 "88b 888    88K      
#    Y88o88P   .d888888 888     888 .d888888 888  888 888 88888888 "Y8888b.           888    888 888  888 888  888 "Y8888b. 888    .d888888 888  888 888    "Y8888b. 
#     Y888P    888  888 888     888 888  888 888 d88P 888 Y8b.          X88 d8b       Y88b  d88P Y88..88P 888  888      X88 Y88b.  888  888 888  888 Y88b.       X88 
#      Y8P     "Y888888 888     888 "Y888888 88888P"  888  "Y8888   88888P' 88P        "Y8888P"   "Y88P"  888  888  88888P'  "Y888 "Y888888 888  888  "Y888  88888P' 
#                                                                           8P                                                                                       
#                                                                           "                                                                                        
#                                                                                                                                                                    
#  88888888888                                            .d8888b.           8888888888                            888    d8b                                        
#      888                                               d88P  "88b          888                                   888    Y8P                                        
#      888                                               Y88b. d88P          888                                   888                                               
#      888     888  888 88888b.   .d88b.  .d8888b         "Y8888P"           8888888    888  888 88888b.   .d8888b 888888 888  .d88b.  88888b.  .d8888b              
#      888     888  888 888 "88b d8P  Y8b 88K            .d88P88K.d88P       888        888  888 888 "88b d88P"    888    888 d88""88b 888 "88b 88K                  
#      888     888  888 888  888 88888888 "Y8888b.       888"  Y888P"        888        888  888 888  888 888      888    888 888  888 888  888 "Y8888b.             
#      888     Y88b 888 888 d88P Y8b.          X88       Y88b .d8888b        888        Y88b 888 888  888 Y88b.    Y88b.  888 Y88..88P 888  888      X88             
#      888      "Y88888 88888P"   "Y8888   88888P'        "Y8888P" Y88b      888         "Y88888 888  888  "Y8888P  "Y888 888  "Y88P"  888  888  88888P'             
#                   888 888                                                                                                                                          
#              Y8b d88P 888                                                                                                                                          
#               "Y88P"  888                                                                                                                                          

[void][System.Reflection.Assembly]::LoadWithPartialName('presentationframework')

# Version
$VersionNumber = "0.9"
$VersionDate   = "2019-08-09"
$VersionAuthor = "Tony Mass� (tony.masse@logrhythm.com)"
$Version       = "v$VersionNumber - $VersionDate - $VersionAuthor"

# Time formats
$TimeStampFormatForJSON = "yyyy-MM-ddTHH:mm:ss.fffZ"
$TimeStampFormatForLogs = "yyyy.MM.dd HH:mm:ss"


#  8888888b.  d8b                           888                     d8b                                                888        .d888 d8b 888                         
#  888  "Y88b Y8P                           888                     Y8P                                                888       d88P"  Y8P 888                         
#  888    888                               888                                                                        888       888        888                         
#  888    888 888 888d888  .d88b.   .d8888b 888888  .d88b.  888d888 888  .d88b.  .d8888b         8888b.  88888b.   .d88888       888888 888 888  .d88b.  .d8888b        
#  888    888 888 888P"   d8P  Y8b d88P"    888    d88""88b 888P"   888 d8P  Y8b 88K                "88b 888 "88b d88" 888       888    888 888 d8P  Y8b 88K            
#  888    888 888 888     88888888 888      888    888  888 888     888 88888888 "Y8888b.       .d888888 888  888 888  888       888    888 888 88888888 "Y8888b.       
#  888  .d88P 888 888     Y8b.     Y88b.    Y88b.  Y88..88P 888     888 Y8b.          X88       888  888 888  888 Y88b 888       888    888 888 Y8b.          X88       
#  8888888P"  888 888      "Y8888   "Y8888P  "Y888  "Y88P"  888     888  "Y8888   88888P'       "Y888888 888  888  "Y88888       888    888 888  "Y8888   88888P'       
#                                                                                                                                                                       
#                                                                                                                                                                       
#                                                                                                                                                                       

# Directories and files information
# Base directory
$basePath = Split-Path (Get-Variable MyInvocation).Value.MyCommand.Path
cd $basePath

# Last Browse directory
$LastBrowsePath = $basePath

# Config directory and file
$configPath = Join-Path -Path $basePath -ChildPath "config"
if (-Not (Test-Path $configPath))
{
	New-Item -ItemType directory -Path $configPath | out-null
}

$configFile = Join-Path -Path $configPath -ChildPath "config.json"

#  888                                 d8b                   
#  888                                 Y8P                   
#  888                                                       
#  888       .d88b.   .d88b.   .d88b.  888 88888b.   .d88b.  
#  888      d88""88b d88P"88b d88P"88b 888 888 "88b d88P"88b 
#  888      888  888 888  888 888  888 888 888  888 888  888 
#  888      Y88..88P Y88b 888 Y88b 888 888 888  888 Y88b 888 
#  88888888  "Y88P"   "Y88888  "Y88888 888 888  888  "Y88888 
#                         888      888                   888 
#                    Y8b d88P Y8b d88P              Y8b d88P 
#                     "Y88P"   "Y88P"                "Y88P"  

# Log directory and file
$logsPath = Join-Path -Path $basePath -ChildPath "logs"
if (-Not (Test-Path $logsPath))
{
	New-Item -ItemType directory -Path $logsPath | out-null
}

$logFile = Join-Path -Path $logsPath -ChildPath ("LogRhythm.OC-UI." + (Get-Date).tostring("yyyyMMdd") + ".log")
if (-Not (Test-Path $logFile))
{
	New-Item $logFile -type file | out-null
}


# Logging functions
function LogMessage([string] $logLevel, [string] $message)
{
    $Msg  = ([string]::Format("{0}|{1}|{2}", (Get-Date).tostring("$TimeStampFormatForLogs"), $logLevel, $message))
	$Msg | Out-File -FilePath $logFile  -Append        
    Write-Host $Msg
}

function LogInfo([string] $message)
{
	LogMessage "INFO" $message
}

function LogError([string] $message)
{
	LogMessage "ERROR" $message
}

function LogDebug([string] $message)
{
	LogMessage "DEBUG" $message
}


#   .d8888b.                    888                      .d8888b.            .d8888b.  888                        888 
#  d88P  Y88b                   888                     d88P  "88b          d88P  Y88b 888                        888 
#  888    888                   888                     Y88b. d88P          888    888 888                        888 
#  888         8888b.   .d8888b 88888b.   .d88b.         "Y8888P"           888        888  .d88b.  888  888  .d88888 
#  888            "88b d88P"    888 "88b d8P  Y8b       .d88P88K.d88P       888        888 d88""88b 888  888 d88" 888 
#  888    888 .d888888 888      888  888 88888888       888"  Y888P"        888    888 888 888  888 888  888 888  888 
#  Y88b  d88P 888  888 Y88b.    888  888 Y8b.           Y88b .d8888b        Y88b  d88P 888 Y88..88P Y88b 888 Y88b 888 
#   "Y8888P"  "Y888888  "Y8888P 888  888  "Y8888         "Y8888P" Y88b       "Y8888P"  888  "Y88P"   "Y88888  "Y88888 
#                                                                                                                     
#                                                                                                                     
#                                                                                                                     

# Cache directory
$cachePath = Join-Path -Path $configPath -ChildPath "Local Cache"
if (-Not (Test-Path $cachePath))
{
	New-Item -ItemType directory -Path $cachePath | out-null
}

# Local copy of the OCHelper.sh script
$OCHelperScriptLocalFile = Join-Path -Path $cachePath -ChildPath "OCHelper.sh"



#  Y88b   d88P        d8888 888b     d888 888            8888888b.                                                       d8b                   
#   Y88b d88P        d88888 8888b   d8888 888            888   Y88b                                                      Y8P                   
#    Y88o88P        d88P888 88888b.d88888 888            888    888                                                                            
#     Y888P        d88P 888 888Y88888P888 888            888   d88P 888d888  .d88b.   .d8888b  .d88b.  .d8888b  .d8888b  888 88888b.   .d88b.  
#     d888b       d88P  888 888 Y888P 888 888            8888888P"  888P"   d88""88b d88P"    d8P  Y8b 88K      88K      888 888 "88b d88P"88b 
#    d88888b     d88P   888 888  Y8P  888 888            888        888     888  888 888      88888888 "Y8888b. "Y8888b. 888 888  888 888  888 
#   d88P Y88b   d8888888888 888   "   888 888            888        888     Y88..88P Y88b.    Y8b.          X88      X88 888 888  888 Y88b 888 
#  d88P   Y88b d88P     888 888       888 88888888       888        888      "Y88P"   "Y8888P  "Y8888   88888P'  88888P' 888 888  888  "Y88888 
#                                                                                                                                          888 
#                                                                                                                                     Y8b d88P 
#                                                                                                                                      "Y88P"  

# ########
# Functions used to decompress/decode compressed/encoded UI XAML:
# - Get-DecompressedByteArray
# - Get-Base64DecodedDecompressedXML

# Function to decompress the XAML. 
function Get-DecompressedByteArray {
	[CmdletBinding()]
    Param (
		[Parameter(Mandatory,ValueFromPipeline,ValueFromPipelineByPropertyName)]
        [byte[]] $byteArray = $(Throw("-byteArray is required"))
    )
	Process {
	    Write-Verbose "Get-DecompressedByteArray"
        $input = New-Object System.IO.MemoryStream( , $byteArray )
	    $output = New-Object System.IO.MemoryStream
        $gzipStream = New-Object System.IO.Compression.GzipStream $input, ([IO.Compression.CompressionMode]::Decompress)
	    $gzipStream.CopyTo( $output )
        $gzipStream.Close()
		$input.Close()
		[byte[]] $byteOutArray = $output.ToArray()
        Write-Output $byteOutArray
    }
}

# Function to Decode the decompressed XAML. Used to decompress/decode compressed/encoded UI XAML
function Get-Base64DecodedDecompressedXML {
	[CmdletBinding()]
    Param (
		[Parameter(Mandatory,ValueFromPipeline,ValueFromPipelineByPropertyName)]
        [string] $Base64EncodedCompressedXML = $(Throw("-Base64EncodedCompressedXML is required"))
    )
    Begin {
        [System.Text.Encoding] $enc = [System.Text.Encoding]::UTF8
    }

	Process {
        [byte[]]$DecodedBytes = [System.Convert]::FromBase64String($Base64EncodedCompressedXML)
        [string]$DecodedText = $enc.GetString( $DecodedBytes )
        $decompressedByteArray = Get-DecompressedByteArray -byteArray $DecodedBytes
        Write-Output $enc.GetString( $decompressedByteArray )
    }
}


#   .d8888b.  888                     888    d8b                   
#  d88P  Y88b 888                     888    Y8P                   
#  Y88b.      888                     888                          
#   "Y888b.   888888  8888b.  888d888 888888 888 88888b.   .d88b.  
#      "Y88b. 888        "88b 888P"   888    888 888 "88b d88P"88b 
#        "888 888    .d888888 888     888    888 888  888 888  888 
#  Y88b  d88P Y88b.  888  888 888     Y88b.  888 888  888 Y88b 888 
#   "Y8888P"   "Y888 "Y888888 888      "Y888 888 888  888  "Y88888 
#                                                              888 
#                                                         Y8b d88P 
#                                                          "Y88P"  

# Starting SmartResponse Plug-In Editor
LogInfo "Starting Open-Collector Helper"
LogInfo ("Version: " + $Version)


#  8888888b.                         888        .d8888b.                     .d888 d8b          
#  888   Y88b                        888       d88P  Y88b                   d88P"  Y8P          
#  888    888                        888       888    888                   888                 
#  888   d88P  .d88b.   8888b.   .d88888       888         .d88b.  88888b.  888888 888  .d88b.  
#  8888888P"  d8P  Y8b     "88b d88" 888       888        d88""88b 888 "88b 888    888 d88P"88b 
#  888 T88b   88888888 .d888888 888  888       888    888 888  888 888  888 888    888 888  888 
#  888  T88b  Y8b.     888  888 Y88b 888       Y88b  d88P Y88..88P 888  888 888    888 Y88b 888 
#  888   T88b  "Y8888  "Y888888  "Y88888        "Y8888P"   "Y88P"  888  888 888    888  "Y88888 
#                                                                                           888 
#                                                                                      Y8b d88P 
#                                                                                       "Y88P"  

# Reading config file
if (-Not (Test-Path $configFile))
{
	LogError "File 'config.json' doesn't exists."
	#LogError "File 'config.json' doesn't exists. Exiting"
    return
}
else
{
    LogInfo "File 'config.json' exists."
}

try
{
	$configJson = Get-Content -Raw -Path $configFile | ConvertFrom-Json
	ForEach ($attribute in @("DocType")) {
		if (-Not (Get-Member -inputobject $configJson -name $attribute -Membertype Properties) -Or [string]::IsNullOrEmpty($configJson.$attribute))
		{
			LogError ($attribute + " has not been specified in 'config.json' file.")
		}
	}
    LogInfo "File 'config.json' parsed correctly."
}
catch
{
	LogError "Could not parse 'config.json' file. Exiting"
	return
}


#   .d8888b.                                    .d8888b.                     .d888 d8b          
#  d88P  Y88b                                  d88P  Y88b                   d88P"  Y8P          
#  Y88b.                                       888    888                   888                 
#   "Y888b.    8888b.  888  888  .d88b.        888         .d88b.  88888b.  888888 888  .d88b.  
#      "Y88b.     "88b 888  888 d8P  Y8b       888        d88""88b 888 "88b 888    888 d88P"88b 
#        "888 .d888888 Y88  88P 88888888       888    888 888  888 888  888 888    888 888  888 
#  Y88b  d88P 888  888  Y8bd8P  Y8b.           Y88b  d88P Y88..88P 888  888 888    888 Y88b 888 
#   "Y8888P"  "Y888888   Y88P    "Y8888         "Y8888P"   "Y88P"  888  888 888    888  "Y88888 
#                                                                                           888 
#                                                                                      Y8b d88P 
#                                                                                       "Y88P"  

function SaveConfigXML 
{
    $configJson = @{"DocType" = "Main Configuration File"
                    ; "LastUpdateTime" = (Get-Date).ToString($TimeStampFormatForJSON)
                    ; "SavedConnection" =
                        @{"Host" = $script:configJson.SavedConnection.Host
                        ; "Port" = $script:configJson.SavedConnection.Port
                        ; "UserName" = $script:configJson.SavedConnection.UserName
                        ; "Password" = $script:configJson.SavedConnection.Password
                        ; "Proxy" = 
                            @{"Host" = $script:configJson.SavedConnection.Proxy.Host
                            ; "Port" = $script:configJson.SavedConnection.Proxy.Port
                            ; "Type" = $script:configJson.SavedConnection.Proxy.Type
                            }
                        }
                   }
    $configJson.LastUpdateTime=(Get-Date).ToString($TimeStampFormatForJSON)

    if ($cbLoginRememberHost.IsChecked) { $configJson.SavedConnection.Host = $tbLoginHost.Text }
    if ($cbLoginOptionsSSHPort.IsChecked) { $configJson.SavedConnection.Port = $tbLoginOptionsSSHPort.Text }
    if ($cbLoginRememberUserName.IsChecked) { $configJson.SavedConnection.UserName = $tbLoginUserName.Text }
    if ($cbLoginRememberPassword.IsChecked) { $configJson.SavedConnection.Password = $tbLoginPassword.Password } ## XXXXX Need to change this to Credentials
    if ($cbLoginOptionsProxyRememberHost.IsChecked) { $configJson.SavedConnection.Proxy.Host = $tbLoginOptionsProxyHost.Text }
    if ($cbLoginOptionsProxyRememberPort.IsChecked) { $configJson.SavedConnection.Proxy.Port = $tbLoginOptionsProxyPort.Text }
    if ($cbLoginOptionsProxyRememberType.IsChecked) { $configJson.SavedConnection.Proxy.Type = $tbLoginOptionsProxyType.Text }
    if ($cbLoginOptionsProxyRememberUserName.IsChecked) { $configJson.SavedConnection.Proxy.UserName = $tbLoginOptionsProxyUserName.Text }
    if ($cbLoginOptionsProxyRememberPassword.IsChecked) { $configJson.SavedConnection.Proxy.Password = $tbLoginOptionsProxyPassword.Password } ## XXXXX Need to change this to Credentials
    
    LogInfo "Saving to 'config.json' file..."
    if (-Not (Test-Path $configFile))
    {
        LogInfo "File 'config.json' doesn't exist. Creating it."
	    New-Item $script:configFile -type file | out-null
    }
    # Write the Config into the Config file
    $configJson | ConvertTo-Json | Out-File -FilePath $script:configFile     
    LogInfo "Configuration saved."

    # Shift the local variable data to the global one
    $script:configJson = $configJson
}

#  8888888b.                         888       Y88b   d88P        d8888 888b     d888 888      
#  888   Y88b                        888        Y88b d88P        d88888 8888b   d8888 888      
#  888    888                        888         Y88o88P        d88P888 88888b.d88888 888      
#  888   d88P  .d88b.   8888b.   .d88888          Y888P        d88P 888 888Y88888P888 888      
#  8888888P"  d8P  Y8b     "88b d88" 888          d888b       d88P  888 888 Y888P 888 888      
#  888 T88b   88888888 .d888888 888  888         d88888b     d88P   888 888  Y8P  888 888      
#  888  T88b  Y8b.     888  888 Y88b 888        d88P Y88b   d8888888888 888   "   888 888      
#  888   T88b  "Y8888  "Y888888  "Y88888       d88P   Y88b d88P     888 888       888 88888888 
#                                                                                              
#                                                                                              
#                                                                                              

# #################
# Reading XAML file
$XAMLFile = "OpenCollector-UI\OC_UI.xaml"

if (Test-Path $XAMLFile)
{
    LogInfo ("File '{0}' exists." -f $XAMLFile)

    try
    {
        LogInfo ("Loading '{0}'..." -f $XAMLFile)
	    [string]$stXAML = Get-Content -Raw -Path $XAMLFile
        LogInfo "Loaded."
    }
    catch
    {
	    LogError ("Could not load '{0}' file. Exiting" -f $XAMLFile)
	    return
    }

}
else 
{
	LogInfo ("External UI definition file '{0}' doesn't exists. Loading from internal description instead." -f $XAMLFile)

# ##########
# "" extracted on  from ".\.xaml".
# Sanitised                          : False
# Raw XAML Size                      : ?? bytes
# Compressed XAML Size               : ?? bytes (saving: ?? bytes)
# Base64 Encoded Compressed XAML Size: ?? bytes (saving: ?? bytes)

$OC_UIvX_X = ""

$stXAML = Get-Base64DecodedDecompressedXML -Base64EncodedCompressedXML $OC_UIvX_X

}

##########
# Sanitise the XAML produced by Visual Studio
$stXAML = $stXAML -replace 'x:Class="[^"]*"'," "
$stXAML = $stXAML -replace 'mc:Ignorable="d"',""
#$stXAML = $stXAML -replace 'x:Name="([^"]*)"','x:Name="$1" Name="$1"'  # Turns out, this cause a lot of troubles :D Getting rid of it :)
$stXAML = $stXAML -replace 'x:Name="([^"]*)"','Name="$1"'
$stXAML = $stXAML -replace '%VERSIONNUMBER%',$VersionNumber
$stXAML = $stXAML -replace '%VERSIONDATE%',$VersionDate
$stXAML = $stXAML -replace '%VERSIONAUTHOR%',$VersionAuthor
         
#########
# Pass the String into an XML
try
{
    LogInfo ("Formatting UI..." -f $XAMLFile)
    [xml]$XAML = $stXAML
    LogInfo "Formatted."
}
catch
{
	LogError ("Failed to format and load the UI design into XML ""{0}"". Exiting" -f $stXAML)
	return
}

###########
# Read XAML
#[void][System.Reflection.Assembly]::LoadWithPartialName('presentationframework')
$reader=(New-Object System.Xml.XmlNodeReader $XAML) 
try
{
    $OCUIForm=[Windows.Markup.XamlReader]::Load( $reader )
}
catch
{
    LogError ("Unable to load Windows.Markup.XamlReader for ConfigReader.MainWindow. Some possible causes for this problem include: .NET Framework is missing PowerShell must be launched with PowerShell -sta, invalid XAML code was encountered. Exception: {0}" -f $_.Exception.Message)
    exit
}


##################################
# Store Form Objects In PowerShell
$xaml.SelectNodes("//*[@Name]") | %{Set-Variable -Name ($_.Name) -Value $OCUIForm.FindName($_.Name)}


#  8888888b.                                                            888     888 8888888 
#  888   Y88b                                                           888     888   888   
#  888    888                                                           888     888   888   
#  888   d88P 888d888  .d88b.  88888b.   8888b.  888d888  .d88b.        888     888   888   
#  8888888P"  888P"   d8P  Y8b 888 "88b     "88b 888P"   d8P  Y8b       888     888   888   
#  888        888     88888888 888  888 .d888888 888     88888888       888     888   888   
#  888        888     Y8b.     888 d88P 888  888 888     Y8b.           Y88b. .d88P   888   
#  888        888      "Y8888  88888P"  "Y888888 888      "Y8888         "Y88888P"  8888888 
#                              888                                                          
#                              888                                                          
#                              888                                                          


##############################
# Hide the Tabs of my TabItems
ForEach ($TabItem in $tcTabs.Items) {
    $TabItem.Visibility="Hidden"
}


##############################
# Disable the Items of lvStep
ForEach ($lvItem in $lvStep.Items) {
    $lvItem.IsEnabled=$false
}


#  888b    888                   d8b                   888    d8b                   
#  8888b   888                   Y8P                   888    Y8P                   
#  88888b  888                                         888                          
#  888Y88b 888  8888b.  888  888 888  .d88b.   8888b.  888888 888  .d88b.  88888b.  
#  888 Y88b888     "88b 888  888 888 d88P"88b     "88b 888    888 d88""88b 888 "88b 
#  888  Y88888 .d888888 Y88  88P 888 888  888 .d888888 888    888 888  888 888  888 
#  888   Y8888 888  888  Y8bd8P  888 Y88b 888 888  888 Y88b.  888 Y88..88P 888  888 
#  888    Y888 "Y888888   Y88P   888  "Y88888 "Y888888  "Y888 888  "Y88P"  888  888 
#                                         888                                       
#                                    Y8b d88P                                       
#                                     "Y88P"                                        

############
# Navigation

# The Navigation tree on the left of the window
$lvStep.Add_SelectionChanged({

    if ($lvStep.Items.Count -gt 0)
    {
        # Move the right tab
        ($tcTabs.Items | where {$_.Header -eq $lvStep.Items[$lvStep.SelectedIndex].Tag}).IsSelected = $true
    
        # Update connection status
        if ($script:SSHSession.Connected -eq $true)
        {
            $IconConnectionDisconnected.Visibility = "Hidden"
            $IconConnectionConnected.Visibility = "Visible"
        }
        else
        {
            $IconConnectionConnected.Visibility = "Hidden"
            $IconConnectionDisconnected.Visibility = "Visible"
        }

        # Check if we are entering a tab that requires refresh
        # If we are, fill the screen with the relevant data
        switch -wildcard ($lvStep.Items[$lvStep.SelectedIndex].Tag) {
            "Welcome"
            {
                try
                {
                    # 
                }
                catch
                {
                    LogError ("Failed to update {1} UI. Exception: {0}." -f $_.Exception.Message, $lvStep.Items[$lvStep.SelectedIndex].Tag)
                }
                break
            }
            "Login"
            {
                try
                {
                    # Bring stuff from the config
                    $tbLoginHost.Text = $configJson.SavedConnection.Host
                    $tbLoginOptionsSSHPort.Text = $configJson.SavedConnection.Port
                    if ($tbLoginOptionsSSHPort.Text.Length -eq 0)
                    {
                        $tbLoginOptionsSSHPort.Text = "22"
                    }
                    $tbLoginUserName.Text = $configJson.SavedConnection.UserName
                    $tbLoginPassword.Password = $configJson.SavedConnection.Password
                    $tbLoginOptionsProxyHost.Text = $configJson.SavedConnection.Proxy.Host
                    $tbLoginOptionsProxyPort.Text = $configJson.SavedConnection.Proxy.Port
                    $tbLoginOptionsProxyType.Text = $configJson.SavedConnection.Proxy.Type
                    $tbLoginOptionsProxyUserName.Text = $configJson.SavedConnection.Proxy.UserName
                    $tbLoginOptionsProxyPassword.Password = $configJson.SavedConnection.Proxy.Password
                }
                catch
                {
                    LogError ("Failed to update {1} UI. Exception: {0}." -f $_.Exception.Message, $lvStep.Items[$lvStep.SelectedIndex].Tag)
                }
                break
            }
            "Status"
            {
                try
                {
                    #
                } # try
                catch
                {
                    LogError ("Failed to update {1} UI. Exception: {0}." -f $_.Exception.Message, $lvStep.Items[$lvStep.SelectedIndex].Tag)
                }
                break
            }
            "Installation"
            {
                try
                {
                    # 
                }
                catch
                {
                    LogError ("Failed to update {1} UI. Exception: {0}." -f $_.Exception.Message, $lvStep.Items[$lvStep.SelectedIndex].Tag)
                }
                break
            }
            "Pipelines"
            {
                try
                {
                    # 
                }
                catch
                {
                    LogError ("Failed to update {1} UI. Exception: {0}." -f $_.Exception.Message, $lvStep.Items[$lvStep.SelectedIndex].Tag)
                }
                break
            }
            default 
            {

                break
            }
        }                


    }
})


#  8888888888 d8b 888                 .d8888b.           8888888b.  d8b                           888                                     .d88888b.                             
#  888        Y8P 888                d88P  "88b          888  "Y88b Y8P                           888                                    d88P" "Y88b                            
#  888            888                Y88b. d88P          888    888                               888                                    888     888                            
#  8888888    888 888  .d88b.         "Y8888P"           888    888 888 888d888  .d88b.   .d8888b 888888  .d88b.  888d888 888  888       888     888 88888b.   .d88b.  88888b.  
#  888        888 888 d8P  Y8b       .d88P88K.d88P       888    888 888 888P"   d8P  Y8b d88P"    888    d88""88b 888P"   888  888       888     888 888 "88b d8P  Y8b 888 "88b 
#  888        888 888 88888888       888"  Y888P"        888    888 888 888     88888888 888      888    888  888 888     888  888       888     888 888  888 88888888 888  888 
#  888        888 888 Y8b.           Y88b .d8888b        888  .d88P 888 888     Y8b.     Y88b.    Y88b.  Y88..88P 888     Y88b 888       Y88b. .d88P 888 d88P Y8b.     888  888 
#  888        888 888  "Y8888         "Y8888P" Y88b      8888888P"  888 888      "Y8888   "Y8888P  "Y888  "Y88P"  888      "Y88888        "Y88888P"  88888P"   "Y8888  888  888 
#                                                                                                                              888                   888                        
#                                                                                                                         Y8b d88P                   888                        
#                                                                                                                          "Y88P"                    888                        

# Function to Browse for a folder
Function Get-DirectoryName()
{   
    param
    (
        [string] $InitialDirectory = "",
        [string] $Description = $null,
        [Switch] $ShowNewFolderButton = $False
    )
    try
    {
        [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

        $OpenFolderDialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $OpenFolderDialog.ShowNewFolderButton = $ShowNewFolderButton
        $OpenFolderDialog.SelectedPath = $InitialDirectory
        $OpenFolderDialog.Description = $Description
        $DialogResult = $OpenFolderDialog.ShowDialog() #| Out-Null
        if ($DialogResult -eq "OK")
        {
            return $OpenFolderDialog.SelectedPath
        }
        else
        {
            return $null
        }
    }
    catch
    {
        LogError "Impossible to browse for directory."
        return $null
    }
}

# Function to Browse for a file
Function Get-FileName()
{   
    param
    (
        [string] $Filter = "All files (*.*)| *.*",
        [string] $InitialDirectory = "",
        [string] $Title = "",
        [Switch] $CheckFileExists = $false,
        [Switch] $ReadOnlyChecked = $false,
        [Switch] $ShowReadOnly = $false,
        [Switch] $Multiselect = $false
    )
    try
    {
        [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

        $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
        $OpenFileDialog.initialDirectory = $InitialDirectory
        $OpenFileDialog.filter = $Filter
        $OpenFileDialog.CheckFileExists = $CheckFileExists
        $OpenFileDialog.ReadOnlyChecked = $ReadOnlyChecked
        $OpenFileDialog.ShowReadOnly = $ShowReadOnly
        $OpenFileDialog.Multiselect = $Multiselect
        $OpenFileDialog.Title = $Title
        $OpenFileDialog.ShowDialog() | Out-Null
        return $OpenFileDialog.filename
    }
    catch
    {
        LogError "Impossible to browse for files."
        return $null
    }
}


#  88888888888                   888    888888b.                                             888 d8b      888          888    d8b                   
#      888                       888    888  "88b                                            888 Y8P      888          888    Y8P                   
#      888                       888    888  .88P                                            888          888          888                          
#      888      .d88b.  888  888 888888 8888888K.   .d88b.  888  888       888  888  8888b.  888 888  .d88888  8888b.  888888 888  .d88b.  88888b.  
#      888     d8P  Y8b `Y8bd8P' 888    888  "Y88b d88""88b `Y8bd8P'       888  888     "88b 888 888 d88" 888     "88b 888    888 d88""88b 888 "88b 
#      888     88888888   X88K   888    888    888 888  888   X88K         Y88  88P .d888888 888 888 888  888 .d888888 888    888 888  888 888  888 
#      888     Y8b.     .d8""8b. Y88b.  888   d88P Y88..88P .d8""8b.        Y8bd8P  888  888 888 888 Y88b 888 888  888 Y88b.  888 Y88..88P 888  888 
#      888      "Y8888  888  888  "Y888 8888888P"   "Y88P"  888  888         Y88P   "Y888888 888 888  "Y88888 "Y888888  "Y888 888  "Y88P"  888  888 
#                                                                                                                                                   
#                                                                                                                                                   
#                                                                                                                                                   

# Setting up the TextBox validation function

[System.Windows.RoutedEventHandler]$textChangedHandler = {
			
    try
    {
        $TextBoxTag = $_.OriginalSource.Tag
        if ($TextBoxTag -match '^ValidIf__(.*)')
        {
            if ($matches.Count -gt 0)
            {
                #LogDebug $matches[1]
                $TextBoxValidated = $false
                $TextBoxText = $_.OriginalSource.Text # Doing this as using $_.OriginalSource.Text in the Switch seems to provide weird results...

                switch -wildcard ($matches[1]) {
                   "NotEmpty"
                   {
                       if (-not ([string]::IsNullOrEmpty($TextBoxText))) { $TextBoxValidated = $true }
                       break
                   }
                   "Empty"
                   {
                       if ([string]::IsNullOrEmpty($TextBoxText)) { $TextBoxValidated = $true }
                       break
                   }
                   "RegEx:*"
                   {
                       $PatternAreYouThere = ($matches[1] -match 'RegEx:(.*)')
                       $Pattern = $matches[1]
                       #LogDebug $Pattern
                       if ($TextBoxText -match $Pattern) { $TextBoxValidated = $true }
                       break
                   }
                   default 
                   {
                       LogDebug ("Validation method un-supported for this TextBox ({0})" -f $matches[1])
                       break
                   }
                }                

                #LogInfo $TextBoxValidated
                if ($TextBoxValidated)
                {  # Valid
                    (([Windows.Media.VisualTreeHelper]::GetParent($_.OriginalSource)).Children | Where-Object {$_ -is [System.Windows.Shapes.Rectangle] }).Fill="#FF007BC2"
                }
                else
                {  # Not valid
                    (([Windows.Media.VisualTreeHelper]::GetParent($_.OriginalSource)).Children | Where-Object {$_ -is [System.Windows.Shapes.Rectangle] }).Fill="Red"
                }
            }
        }
    }
    catch
    {
        LogError "TextBox validation failed."
    }
}

$OCUIForm.AddHandler([System.Windows.Controls.TextBox]::TextChangedEvent, $textChangedHandler)


#  888    888 d8b          888            888                                 888       888888b.   d8b               888 d8b                            
#  888    888 Y8P          888            888                                 888       888  "88b  Y8P               888 Y8P                            
#  888    888              888            888                                 888       888  .88P                    888                                
#  8888888888 888  .d88b.  88888b.        888       .d88b.  888  888  .d88b.  888       8888888K.  888 88888b.   .d88888 888 88888b.   .d88b.  .d8888b  
#  888    888 888 d88P"88b 888 "88b       888      d8P  Y8b 888  888 d8P  Y8b 888       888  "Y88b 888 888 "88b d88" 888 888 888 "88b d88P"88b 88K      
#  888    888 888 888  888 888  888       888      88888888 Y88  88P 88888888 888       888    888 888 888  888 888  888 888 888  888 888  888 "Y8888b. 
#  888    888 888 Y88b 888 888  888       888      Y8b.      Y8bd8P  Y8b.     888       888   d88P 888 888  888 Y88b 888 888 888  888 Y88b 888      X88 
#  888    888 888  "Y88888 888  888       88888888  "Y8888    Y88P    "Y8888  888       8888888P"  888 888  888  "Y88888 888 888  888  "Y88888  88888P' 
#                      888                                                                                                                 888          
#                 Y8b d88P                                                                                                            Y8b d88P          
#                  "Y88P"                                                                                                              "Y88P"           

#$dgTestTestsOrder.ItemsSource = $ProjectMemoryObject.Tests



#  888     888 8888888                    888       888          888                                                888             888      
#  888     888   888                      888   o   888          888                                                888             888      
#  888     888   888                      888  d8b  888          888                                                888             888      
#  888     888   888                      888 d888b 888  .d88b.  888  .d8888b  .d88b.  88888b.d88b.   .d88b.        888888  8888b.  88888b.  
#  888     888   888                      888d88888b888 d8P  Y8b 888 d88P"    d88""88b 888 "888 "88b d8P  Y8b       888        "88b 888 "88b 
#  888     888   888         888888       88888P Y88888 88888888 888 888      888  888 888  888  888 88888888       888    .d888888 888  888 
#  Y88b. .d88P   888                      8888P   Y8888 Y8b.     888 Y88b.    Y88..88P 888  888  888 Y8b.           Y88b.  888  888 888 d88P 
#   "Y88888P"  8888888                    888P     Y888  "Y8888  888  "Y8888P  "Y88P"  888  888  888  "Y8888         "Y888 "Y888888 88888P"  
#                                                                                                                                            
#                                                                                                                                            
#                                                                                                                                            

$btWelcomeIAgree.Add_Click({
    ##############################
    # Disable the Items of lvStep
    ForEach ($lvItem in $lvStep.Items) {
        $lvItem.IsEnabled=$true
    }
    $lvStep.SelectedIndex = 1 # Login
})

$btWelcomeExit.Add_Click({
    $OCUIForm.Close()
})


#  888     888 8888888                    888                        d8b                888             888      
#  888     888   888                      888                        Y8P                888             888      
#  888     888   888                      888                                           888             888      
#  888     888   888                      888       .d88b.   .d88b.  888 88888b.        888888  8888b.  88888b.  
#  888     888   888                      888      d88""88b d88P"88b 888 888 "88b       888        "88b 888 "88b 
#  888     888   888         888888       888      888  888 888  888 888 888  888       888    .d888888 888  888 
#  Y88b. .d88P   888                      888      Y88..88P Y88b 888 888 888  888       Y88b.  888  888 888 d88P 
#   "Y88888P"  8888888                    88888888  "Y88P"   "Y88888 888 888  888        "Y888 "Y888888 88888P"  
#                                                                888                                             
#                                                           Y8b d88P                                             
#                                                            "Y88P"                                              

$btLoginConnect.Add_Click({
    if ((get-module PoSH-SSH -ListAvailable).Count -lt 1)
    {
        # The right module is not installed
        LogError "The SSH module for PowerShell is not yet installed on this computer."
        $MsgBoxResponse = [System.Windows.MessageBox]::Show("The SSH module for PowerShell is not yet installed on this computer.`n`nWould  you like to install it?`n`nNote: the installation requires to be done as Administrator.",'SSH Module','YesNo','Error')
        switch  ($MsgBoxResponse) {
          'Yes' {
            try
            {
                # Install it as Admin
                LogInfo "Installing the SSH module as Administrator."
                Start-Process powershell -Verb runAs "install-module PoSH-SSH"
            }
            catch
            {
                LogError ("The SSH module failed to install. Exception: {0}." -f $_.Exception.Message)
            }
          }
          'No' {
            LogError "The SSH module is required for this connection to work. Connection not established."
            [System.Windows.MessageBox]::Show("The SSH module is required for this connection to work.`n`nConnection not established.",'SSH Module','Ok','Information')
          }
        }
    }
    else
    {
        try
        {
            # ######################
            # Build the credentials

            # For the Open Collector Host
            $HostUser = $tbLoginUserName.Text
            if ($tbLoginPassword.Password.Length -gt 0)
            {
                $HostPass = convertto-securestring $tbLoginPassword.Password -asplaintext -force
            }
            else
            {
                $HostPass = (new-object System.Security.SecureString)
            }

            $HostCreds = New-Object System.Management.Automation.PSCredential -ArgumentList $HostUser, $HostPass

            # For the Proxy
            if ($tbLoginOptionsProxyUserName.Text.Length -gt 0)
            {
                try
                {
                    $ProxyUser = $tbLoginOptionsProxyUserName.Text
                    if ($tbLoginOptionsProxyPassword.Password.Length -gt 0)
                    {
                        $ProxyPass = convertto-securestring $tbLoginOptionsProxyPassword.Password -asplaintext -force
                    }
                    else
                    {
                        $ProxyPass = (new-object System.Security.SecureString)
                    }
                    $ProxyCredentials = New-Object System.Management.Automation.PSCredential -ArgumentList $ProxyUser, $ProxyPass
                }
                catch
                {
                    $ProxyCredentials = $null
                    $ProxyUser = "" # This prevents the Proxy credentials to be provided to the connection
                    LogError ("Failed to process Proxy Credentials. Exception: {0}." -f $_.Exception.Message)
                    [System.Windows.MessageBox]::Show(("Failed to process Proxy Credentials.`n`nException: {0}." -f $_.Exception.Message),'SSH Connection','Ok','Error')
                }
            }

            # #######################
            # Connect

            if ($tbLoginOptionsProxyHost.Text.Length -eq 0)
            {
                # No proxy, direct connection
                $script:SSHSession = New-SSHSession -ComputerName $tbLoginHost.Text -Port $tbLoginOptionsSSHPort.Text.ToInt32($null) -Credential $HostCreds -KeepAliveInterval 100 -AcceptKey
            }
            else 
            {
                # There is a Proxy
                if ($tbLoginOptionsProxyUserName.Text.Length -gt 0)
                {
                    # There are some Proxy credentials
                    $script:SSHSession = New-SSHSession -ComputerName $tbLoginHost.Text -Port $tbLoginOptionsSSHPort.Text.ToInt32($null) -Credential $HostCreds -KeepAliveInterval 100 -AcceptKey -ProxyServer $tbLoginOptionsProxyHost.Text -ProxyPort $tbLoginOptionsProxyPort.Text.ToInt32($null) -ProxyType $tbLoginOptionsProxyType.Text -ProxyCredential $ProxyCredentials
                }
                else
                {
                    # No Proxy credentials
                    $script:SSHSession = New-SSHSession -ComputerName $tbLoginHost.Text -Port $tbLoginOptionsSSHPort.Text.ToInt32($null) -Credential $HostCreds -KeepAliveInterval 100 -AcceptKey -ProxyServer $tbLoginOptionsProxyHost.Text -ProxyPort $tbLoginOptionsProxyPort.Text.ToInt32($null) -ProxyType $tbLoginOptionsProxyType.Text
                }
            }
            if ($script:SSHSession.Connected)
            {
                LogInfo ("Connected to host ""{0}:{2}"" as user ""{1}"" over SSH." -f $tbLoginHost.Text, $HostUser, $tbLoginOptionsSSHPort.Text)
                $IconConnectionDisconnected.Visibility = "Hidden"
                $IconConnectionConnected.Visibility = "Visible"
                $btLoginConnect.IsEnabled = $false
                $btLoginDisconnect.IsEnabled = $true
            }
            else
            {
                LogError ("Failed to connect to host ""{0}:{2}"" as user ""{1}"" over SSH. Check host, username and password and try again." -f $tbLoginHost.Text, $HostUser, $tbLoginOptionsSSHPort.Text)
                [System.Windows.MessageBox]::Show(("Failed to connect to host ""{0}:{2}"" as user ""{1}"" over SSH.`n`nCheck Host, User Name and Password and try again." -f $tbLoginHost.Text, $HostUser, $tbLoginOptionsSSHPort.Text),'SSH Connection','Ok','Error')
            }

        }
        catch
        {
            LogError ("Failed to connect to host over SSH. Exception: {0}." -f $_.Exception.Message)
            [System.Windows.MessageBox]::Show(("Failed to connect to host over SSH.`n`nException: {0}." -f $_.Exception.Message),'SSH Connection','Ok','Error')
        }

    }
})

function SSHDisconnect()
{
    if ((get-module PoSH-SSH -ListAvailable).Count -lt 1)
    {
        # The right module is not installed
        LogError "The SSH module for PowerShell is not yet installed on this computer."
    }
    else
    {
        try
        {
            # #######################
            # Disconnect then clear up all connections

            LogInfo "Disconnect then clear up all SSH connections"

            $Sessions = Get-SSHSession
            foreach ($Session in $Sessions)
            {
                try
                {
                    $Session.Disconnect()
                    Remove-SSHSession -SSHSession $Session | Out-Null
                    LogInfo (" \-- Connection disconnected (Connection ID: {0}) from Host {1}." -f $Session.SessionId, $Session.Host)
                }
                catch
                {
                    LogError (" \-- Failed to disconnect (Connection ID: {1}) from Host {2}. Exception: {0}." -f $_.Exception.Message, $Session.SessionId, $Session.Host)
                }
            }
        }
        catch
        {
        }
    }
}



$btLoginDisconnect.Add_Click({
    if ((get-module PoSH-SSH -ListAvailable).Count -lt 1)
    {
        # The right module is not installed
        LogError "The SSH module for PowerShell is not yet installed on this computer."
    }
    else
    {
        try
        {
            SSHDisconnect
            $IconConnectionConnected.Visibility = "Hidden"
            $IconConnectionDisconnected.Visibility = "Visible"
            $btLoginConnect.IsEnabled = $true
            $btLoginDisconnect.IsEnabled = $false
            $script:SSHSession = $null
        }
        catch
        {
            LogError ("Failed to disconnect from Open-Collector. Exception: {0}." -f $_.Exception.Message)
        }

    }
})


#  888     888 8888888                     .d8888b.  888             888                            888             888      
#  888     888   888                      d88P  Y88b 888             888                            888             888      
#  888     888   888                      Y88b.      888             888                            888             888      
#  888     888   888                       "Y888b.   888888  8888b.  888888 888  888 .d8888b        888888  8888b.  88888b.  
#  888     888   888                          "Y88b. 888        "88b 888    888  888 88K            888        "88b 888 "88b 
#  888     888   888         888888             "888 888    .d888888 888    888  888 "Y8888b.       888    .d888888 888  888 
#  Y88b. .d88P   888                      Y88b  d88P Y88b.  888  888 Y88b.  Y88b 888      X88       Y88b.  888  888 888 d88P 
#   "Y88888P"  8888888                     "Y8888P"   "Y888 "Y888888  "Y888  "Y88888  88888P'        "Y888 "Y888888 88888P"  
#                                                                                                                            
#                                                                                                                            
#                                                                                                                            

function GetOpenCollectorInstalledPipeline
{
    # #########
    # Get the Open-Collector installed pipelines
    try
    {
        $SHHCommandReturn = Invoke-SSHCommand -SSHSession $script:SSHSession -Command ("./OCHelper.sh --ListInstalledPipelines") -TimeOut 5
    }
    catch
    {
        # Oopsy Daisy... Something went wrong
        LogError ("Failed to list the Installed Pipelines of ""Open-Collector"". Exception: {0}." -f $_.Exception.Message)
    }

    if ($SHHCommandReturn.ExitStatus -eq 0)
    {
        try
        {
            $Response = $SHHCommandReturn.Output | ConvertFrom-Json
            LogInfo ("Found {0} Installed Pipleines in Open-Collector." -f $Response.Count)
            # Clear the current list of Pipelines
            $dgStatusInstalledPipelines.Items.Clear()
            # Add all the ones we got from OCHelper
            foreach ($InstalledPipeline in $Response)
            {
                # Create a new blank Pipeline entry
                $NewPipelineItem = Select-Object -inputobject "" Name,Status
                LogInfo (" \-- Found Pipeline ""{0}"", with status: ""{1}""." -f $InstalledPipeline.PipelineName, $InstalledPipeline.Enabled)
                
                # CHeck the Status
                if ($InstalledPipeline.Enabled -eq "true")
                {
                    $NewPipelineItem.Status = "Enabled"
                }
                else
                {
                    $NewPipelineItem.Status = "Disabled"
                }
                                    
                # We might decide later to translate the full pipeline name into a shorter one. For now, I just keep as is.
                $NewPipelineItem.Name = $InstalledPipeline.PipelineName

                # Add to the table
                $dgStatusInstalledPipelines.Items.Add($NewPipelineItem)
            }
        }
        catch
        {
            LogError ("Failed to read OCHelper JSON output. Exception: {0}." -f $_.Exception.Message)
        }
    }
}

$btStatusInstalledPipelinesRefresh.Add_Click({
    # Refresh the Installed Pipeline list
    GetOpenCollectorInstalledPipeline
})

function RefreshStatusTab
{
    # Are we connected?
    if ($script:SSHSession.Connected)
    {
        # ####################
        # Refresh the statuses

        # #########
        # Check for the presense of OCHelper.sh
        try
        {
            $SHHCommandReturn = Invoke-SSHCommand -SSHSession $script:SSHSession -Command ("ls ./OCHelper.sh") -TimeOut 2
        }
        catch
        {
            # Oopsy Daisy... Something went wrong
            LogError ("Failed to check for the presense of ""OCHelper.sh"". Exception: {0}." -f $_.Exception.Message)
        }

        if ($SHHCommandReturn.ExitStatus -eq 0)
        {
            $rbStatusOCHelperInstalled.IsChecked = $true
            LogInfo """OCHelper.sh"" presence: true."
        }
        else
        {
            $rbStatusOCHelperMissing.IsChecked = $true
            LogInfo """OCHelper.sh"" presence: false."
        }

        # #########
        # Check for the presense of Docker
        try
        {
            $SHHCommandReturn = Invoke-SSHCommand -SSHSession $script:SSHSession -Command ("./OCHelper.sh --CheckDockerPresence") -TimeOut 2
        }
        catch
        {
            # Oopsy Daisy... Something went wrong
            LogError ("Failed to check for the presense of ""Docker"". Exception: {0}." -f $_.Exception.Message)
        }

        if ($SHHCommandReturn.ExitStatus -eq 0)
        {
            $rbStatusDockerInstalled.IsChecked = $true
            try
            {
                $Response = $SHHCommandReturn.Output | ConvertFrom-Json
                LogInfo ("Docker presence: {0}." -f $Response.Presence)
            }
            catch
            {
                LogError ("Failed to read OCHelper JSON output. Exception: {0}." -f $_.Exception.Message)
            }
            if ($Response.Presence.ToLower() -ne "true")
            {
                $rbStatusDockerNone.IsChecked = $true
            }
        }
        else
        {
            $rbStatusDockerNone.IsChecked = $true
        }

        # #########
        # Check for the version of Docker
        try
        {
            $SHHCommandReturn = Invoke-SSHCommand -SSHSession $script:SSHSession -Command ("./OCHelper.sh --CheckDockerVersion") -TimeOut 5
        }
        catch
        {
            # Oopsy Daisy... Something went wrong
            LogError ("Failed to check for the version of ""Docker"". Exception: {0}." -f $_.Exception.Message)
        }

        if ($SHHCommandReturn.ExitStatus -eq 0)
        {
            $rbStatusDockerRunning.IsChecked = $true
            try
            {
                $Response = $SHHCommandReturn.Output | ConvertFrom-Json
                LogInfo ("Docker version {0}." -f $Response.Version.Full)
                $lbStatusDockerVersion.Content = $Response.Version.Full
            }
            catch
            {
                LogError ("Failed to read OCHelper JSON output. Exception: {0}." -f $_.Exception.Message)
            }
        }

        # #########
        # Check for the presense of the Open-Collector
        try
        {
            $SHHCommandReturn = Invoke-SSHCommand -SSHSession $script:SSHSession -Command ("./OCHelper.sh --CheckOCPresence") -TimeOut 10
        }
        catch
        {
            # Oopsy Daisy... Something went wrong
            LogError ("Failed to check for the presense of ""Open-Collector"". Exception: {0}." -f $_.Exception.Message)
        }

        if ($SHHCommandReturn.ExitStatus -eq 0)
        {
            $rbStatusOpenCollectorInstalled.IsChecked = $true
            try
            {
                $Response = $SHHCommandReturn.Output | ConvertFrom-Json
                LogInfo ("Open-Collector presence: {0}." -f $Response.Presence)
            }
            catch
            {
                LogError ("Failed to read OCHelper JSON output. Exception: {0}." -f $_.Exception.Message)
            }
            if ($Response.Presence.ToLower() -ne "true")
            {
                $rbStatusOpenCollectorNone.IsChecked = $true
            }
        }
        else
        {
            $rbStatusOpenCollectorNone.IsChecked = $true
        }

        # #########
        # Check for the version of Open-Collector
        try
        {
            $SHHCommandReturn = Invoke-SSHCommand -SSHSession $script:SSHSession -Command ("./OCHelper.sh --CheckOCVersion") -TimeOut 10
        }
        catch
        {
            # Oopsy Daisy... Something went wrong
            LogError ("Failed to check for the version of ""Open-Collector"". Exception: {0}." -f $_.Exception.Message)
        }

        if ($SHHCommandReturn.ExitStatus -eq 0)
        {
            try
            {
                $Response = $SHHCommandReturn.Output | ConvertFrom-Json
                LogInfo ("Open-Collector version {0}." -f $Response.Version.Full)
                $lbStatusOpenCollectorVersion.Content = $Response.Version.Full
            }
            catch
            {
                LogError ("Failed to read OCHelper JSON output. Exception: {0}." -f $_.Exception.Message)
            }
        }

        # #########
        # Check for the health of Open-Collector
        try
        {
            $SHHCommandReturn = Invoke-SSHCommand -SSHSession $script:SSHSession -Command ("./OCHelper.sh --CheckOCHealth") -TimeOut 10
        }
        catch
        {
            # Oopsy Daisy... Something went wrong
            LogError ("Failed to check for the health of ""Open-Collector"". Exception: {0}." -f $_.Exception.Message)
        }

        if ($SHHCommandReturn.ExitStatus -eq 0)
        {
            try
            {
                $Response = $SHHCommandReturn.Output | ConvertFrom-Json
                LogInfo ("Open-Collector health status ""{0}""." -f $Response.Health)
                If ($Response.Health.ToLower() -eq "up")
                {
                    $rbStatusOpenCollectorRunning.IsChecked = $true
                }
                else
                {
                    LogInfo ("Health of ""Open-Collector"" is set to ""{0}""." -f $Response.Health)
                }

            }
            catch
            {
                LogError ("Failed to read OCHelper JSON output. Exception: {0}." -f $_.Exception.Message)
            }
        }

        # #########
        # Get the Open-Collector installed pipelines
        GetOpenCollectorInstalledPipeline

    } # if ($script:SSHSession.Connected)
}

$btStatusRefresh.Add_Click({
    # Refresh the whole Status page
    RefreshStatusTab
})


#  8888888888                                     888    d8b                   
#  888                                            888    Y8P                   
#  888                                            888                          
#  8888888    888  888  .d88b.   .d8888b 888  888 888888 888  .d88b.  88888b.  
#  888        `Y8bd8P' d8P  Y8b d88P"    888  888 888    888 d88""88b 888 "88b 
#  888          X88K   88888888 888      888  888 888    888 888  888 888  888 
#  888        .d8""8b. Y8b.     Y88b.    Y88b 888 Y88b.  888 Y88..88P 888  888 
#  8888888888 888  888  "Y8888   "Y8888P  "Y88888  "Y888 888  "Y88P"  888  888 
#                                                                              
#                                                                              
#                                                                              

########################################################################################################################
##################################################### Execution!!  #####################################################
########################################################################################################################

# Run the UI
$OCUIForm.ShowDialog() | out-null

# Disconnect any left over connections
SSHDisconnect

# Save the configuration
SaveConfigXML

# Time to depart, my old friend...
LogInfo "Exiting Open-Collector Helper"
# Didn't we have a joly good time?
